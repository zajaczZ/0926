﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        private string szerzo;
        private string tartalom;
        private int likeok;
        private DateTime letrejott;
        private DateTime szerkesztve;

        public Bejegyzes(string szerzo, string tartalom)
        {
            this.szerzo = szerzo;
            this.tartalom = tartalom;
            this.likeok = 0;
            this.letrejott = DateTime.Now;
            this.szerkesztve = DateTime.Now;
        }

        public string Szerzo { get { return szerzo; } }
        public string Tartalom
        {
            get { return tartalom; }
            set
            {
                tartalom = value;
                szerkesztve = DateTime.Now;
            }
        }
        public int Likeok { get { return likeok; } }
        public DateTime Letrejott { get { return letrejott; } }
        public DateTime Szerkesztve { get { return szerkesztve; } }

        public void Like()
        {
            likeok++;
        }

        public override string ToString()
        {
            string szerkesztveStr = szerkesztve == letrejott ? "" : $"Szerkeszve: {szerkesztve}";
            return $"{szerzo} - {likeok} - {letrejott} {szerkesztveStr}: {tartalom}";
        }
        static void f()
        {
            Console.Write("Adjon meg egy darabszámot: ");
            if (int.TryParse(Console.ReadLine(), out int darabszam))
            {
                for (int i = 0; i < darabszam; i++)
                {
                    Console.Write($"Adja meg a(z) {i + 1}. bejegyzés szerzőjét: ");
                    string szerzo = Console.ReadLine();
                    Console.Write($"Adja meg a(z) {i + 1}. bejegyzés tartalmát: ");
                    string tartalom = Console.ReadLine();

                    Bejegyzes bejegyzes = new Bejegyzes(szerzo, tartalom);
                    bejegyzesLista1.Add(bejegyzes);
                }
            }
            else
            {
                Console.WriteLine("Hibás bemenet. Csak természetes számot adjon meg.");
            }

        }

        static void Main(string[] args)
        {
            List<Bejegyzes> bejegyzesLista1 = new List<Bejegyzes>();
            List<Bejegyzes> bejegyzesLista2 = new List<Bejegyzes>();
        }
    }
}
